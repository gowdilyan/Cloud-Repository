#!/bin/bash

echo -e "\e[1;36m  "Provisioning Virtual machine" \e[0m"
echo -e "\e[1;36m  "Updating the system" \e[0m"

sudo apt-get -y update

echo -e "\e[1;36m  "Installing Java" \e[0m"
sudo apt-get -y install default-jre
sudo apt-get -y install default-jdk

echo -e "\e[1;36m  "Installing Tomcat" \e[0m"
sudo apt-get -y install tomcat7

echo -e "\e[1;36m "Installing Version Control System" \e[0m"
sudo apt-get -y install git

echo -e "\e[1;36m  "Connecting Version Control Repository" \e[0m"
sudo git clone https://github.com/gowdilyan/Cloud-Demo.git
echo -e "\e[1;36m  "Application source code downloaded to local" \e[0m"

echo -e "\e[1;36m  "Deploying the Application" \e[0m"
sudo cp /home/vagrant/Cloud-Demo/TestWar.war /var/lib/tomcat7/webapps/TestWar.war

echo -e "\e[1;36m  "Tomcat Server is Up and Running" \e[0m"
