#!/bin/bash

echo "Provisioning Virtual machine"
echo "Updating the system"

sudo apt-get -y update

echo "Installing Java"
sudo apt-get -y install default-jre
sudo apt-get -y install default-jdk

echo "Installing Tomcat"
sudo apt-get -y install tomcat7

echo "Installing sysstat"
sudo apt-get -y install git

echo "creating directory"
mkdir new1
